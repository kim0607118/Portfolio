# DE1-SOC_Pong_Game
A pong game in Verilog using the DE1-SOC FPGA (Cyclone V). Uses a PS2 Keyboard, and outputs to a VGA display.
